


Credits:

HTML5

	Icons:
		Font Awesome (fontawesome.io)

	Other:
		jQuery (jquery.com)
		Github Pages
		Responsive Tools (github.com/ajlkn/responsive-tools)